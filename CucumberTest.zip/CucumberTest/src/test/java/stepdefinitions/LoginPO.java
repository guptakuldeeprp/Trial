package stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPO {

	public LoginPO(WebDriver driver) {
		this.driver = driver;
	}

	private WebDriver driver;
	private String url = "https://example.testproject.io/web/";
	private By txtUsername = By.id("name");
	private By txtPassword = By.id("password");
	private By btnLogin = By.id("login");
	private By btnLogout = By.id("logout");
	
	public void gotoPage() {
		driver.navigate().to(url);
	}

	public void enterUsernamePwd(String username, String password) {
		driver.findElement(txtUsername).sendKeys(username);
		driver.findElement(txtPassword).sendKeys(password);
	}

	public void login() {
		driver.findElement(btnLogin).click();
	}

	public void hasLogout() {
		driver.findElement(btnLogout);
	}

	public void logout() {
		driver.findElement(btnLogout).click();
	}

	public void loginWithUsernamePwd(String username, String password) {
		enterUsernamePwd(username, password);
		login();
	}

}
